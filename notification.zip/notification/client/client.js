const publicVapidKey = "BEOjo0bkAM9KMQU1XnQQs09JYrmKYQiMLyejxpsg37WIR3XU7928sk_M1ZZCsV7yKDr7P8_8Q1sbvWIXqbLuTJE";
var dataab = [];
// Check for service worker
if ("serviceWorker" in navigator) {
  getData();
  
}

function getData() {
    //return Math.random();
    //const textviewcount = document.getElementById('viewcount');
    fetch('https://nowexpress.khanmuham.now.sh/users').then(response => response.json()).then(data =>{
        console.log(data);
        for(var i =0; i<data.length;i++){
            dataab[i]=  parseInt(data[i].Temperature);
            if(dataab[i] > 10)
            {
              send().catch(err => console.error(err));
            }
            
        }
    //console.log(data[i].Temperature);
    })
    .catch(function(error){
        console.log(error);
    });
}  

// Register SW, Register Push, Send Push
async function send() {
  //getData();
  
  // Register Service Worker
  console.log("Registering service worker...");
  const register = await navigator.serviceWorker.register("/worker.js", {
    scope: "/"
  });
  console.log("Service Worker Registered...");

  // Register Push
  console.log("Registering Push...");
  const subscription = await register.pushManager.subscribe({
    userVisibleOnly: true,
    applicationServerKey: urlBase64ToUint8Array(publicVapidKey)
  });
  console.log("Push Registered...");

  // Send Push Notification
  console.log("Sending Push...");
  await fetch("/subscribe", {
    method: "POST",
    body: JSON.stringify(subscription),
    headers: {
      "content-type": "application/json"
    }
  });
  console.log("Push Sent...");
}

function urlBase64ToUint8Array(base64String) {
  const padding = "=".repeat((4 - base64String.length % 4) % 4);
  const base64 = (base64String + padding)
    .replace(/\-/g, "+")
    .replace(/_/g, "/");

  const rawData = window.atob(base64);
  const outputArray = new Uint8Array(rawData.length);

  for (let i = 0; i < rawData.length; ++i) {
    outputArray[i] = rawData.charCodeAt(i);
  }
  return outputArray;
}